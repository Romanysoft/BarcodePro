/**
 * Created by kevin on 11/28/13.
 */


var app = {
    showAdsUpgrade:function(){
        $('#ads_upgrade').click();
    }
};


(function(){
    // Image popups
    $('#image-popups').magnificPopup({
      delegate: 'a',
      type: 'image',
      removalDelay: 500, //delay removal by X to allow out-animation
      callbacks: {
        beforeOpen: function() {
          // just a hack that adds mfp-anim class to markup 
           this.st.image.markup = this.st.image.markup.replace('mfp-figure', 'mfp-figure mfp-with-anim');
           this.st.mainClass = this.st.el.attr('data-effect');
        }
      },
      closeOnContentClick: true,
      midClick: true // allow opening popup on middle mouse click. Always set it to true if you don't provide alternative source.
    });

	$("#textButton").on('click',function(){
            var saveType = $('#saveType').val() || 'jpg'; // default save img type
            var dataUrlStr = $('#barcode canvas')[0].toDataURL('image/jpg');

            var params = {
                callback: 'window.handSaveFileFuc',
                types:[saveType]
            };
            var paramStr = JSON.stringify(params);
            window['handSaveFileFuc'] = function(obj){
                if (obj.success){
                    //get the path, then save
                    var params = {
                        "callback":'window.handBase64ToImageFileFunc',
                        "imageType":$('#saveType').val() || 'jpg',
                        "filePath":obj.filePath,
                        "base64String":dataUrlStr.split(',')[1] // 去除data:imgaes/jpg;base64,字符串
                    };
                    var paramStr = JSON.stringify(params);
                    window['handBase64ToImageFileFunc'] = function(obj){
						if (obj.success){
							//get the result
							var result = obj.result;

							//reveal in finder
							var params = {
								filePath: obj.filePath
							};

							var paramStr = JSON.stringify(params);
							try{
								(typeof macgap) && (macgap.window.revealInFinder(paramStr));
							}catch(e){console.error(e)}



						}else {
							//Error
						   alert('save error! please send email to app.romanysoft@gmail.com!');
						}
                    }
					
					// 启动处理
                    try{
                        (typeof macgap) && (macgap.binaryFileWriter.base64ToImageFile(paramStr));
                    }catch(e){console.log(e)}

                }

            };

            try{
                (typeof macgap) && (macgap.window.saveFile(paramStr));
            }catch(e){console.error(e)}
	});


     setTimeout(function(){
        app.showAdsUpgrade();
      },
     5000);

})();
